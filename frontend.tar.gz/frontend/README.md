src/
├── features/
│ └── auth/
│ ├── api/
│ │ └── register.ts
│ ├── components/
│ │ └── RegisterForm.tsx
│ ├── validation/
│ │ └── registerSchema.ts
│ └── useRegister.ts
├── pages/
│ └── RegisterPage.tsx
