import { AdminDocumentReviewDetails } from '@/features/documentReviewAdmin/components/AdminDocumentReviewDetails';

export default function AdminDocumentReviewDetailsPage() {
  return (
    <div className="p-6 space-y-6">
      <AdminDocumentReviewDetails />
    </div>
  );
}
