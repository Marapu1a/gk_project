declare module 'smoothscroll-polyfill' {
  const smoothscroll: { polyfill(): void };
  export default smoothscroll;
}
