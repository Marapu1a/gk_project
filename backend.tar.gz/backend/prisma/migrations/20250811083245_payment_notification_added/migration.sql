-- AlterEnum
ALTER TYPE "NotificationType" ADD VALUE 'PAYMENT';
