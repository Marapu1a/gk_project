-- AlterEnum
ALTER TYPE "NotificationType" ADD VALUE 'NEW_USER';
