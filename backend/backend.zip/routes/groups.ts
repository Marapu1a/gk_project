import { FastifyInstance } from 'fastify'
import { addUserToGroupHandler } from '../handlers/groups/add'
import { removeUserFromGroupHandler } from '../handlers/groups/remove'
import { verifyToken } from '../middlewares/verifyToken'

export async function groupRoutes(app: FastifyInstance) {
  app.post('/groups/:groupName/add', { preHandler: verifyToken }, addUserToGroupHandler)
  app.post('/groups/:groupName/remove', { preHandler: verifyToken }, removeUserFromGroupHandler)
}
