import { FastifyInstance } from 'fastify';
import { createCertificate } from '../handlers/certificates/createCertificate';
import { verifyToken } from '../middlewares/verifyToken';

export async function certificateRoutes(app: FastifyInstance) {
  app.post('/certificates', { preHandler: verifyToken }, createCertificate);
}
